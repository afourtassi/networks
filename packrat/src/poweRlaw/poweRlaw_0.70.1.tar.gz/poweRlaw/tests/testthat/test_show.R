## Not sure how to do this. At the very least this will pick up errors.
test_that("Testing printing for reference class objects", {
  data(moby, package="poweRlaw")
  conpl$new(moby); 
}
)
