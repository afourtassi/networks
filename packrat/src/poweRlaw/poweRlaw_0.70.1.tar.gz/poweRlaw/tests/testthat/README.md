### Test suite

The data files discrete_data.txt and continuous_data.txt are the 
original example files from Aaron Clausets own implementation of 
the power law fitting method. Fitting discrete_data.txt should 
result in alpha = 2.58, xmin = 2 and a log-likelihood of -9155.63.

I got the data from https://github.com/ntamas/plfit/