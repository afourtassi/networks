library("testthat")
library("papaja")

test_check("papaja")
