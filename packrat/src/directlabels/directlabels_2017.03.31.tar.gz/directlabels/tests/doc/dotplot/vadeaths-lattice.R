library(lattice)
dotplot(VADeaths,xlim=c(8,85),type="o")
