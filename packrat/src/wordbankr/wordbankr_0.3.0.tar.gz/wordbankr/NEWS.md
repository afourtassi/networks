* compatibility with tidyeval
* new functionality for metadata on data sources
* new functionality for age of acquisition estimates
* new functionality for cross-linguistic mapping
* function and argument naming consistency
* bug fixes and performance improvements