* additional fields in `get_administration_data()`: `zygosity`, `original_id`, `norming`, `longitudinal`, `source_name`
* minor bug fixes
* faster queries